package com.example.flutter_thrio_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
