//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"

#if __has_include(<thrio/ThrioPlugin.h>)
#import <thrio/ThrioPlugin.h>
#else
@import thrio;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [ThrioPlugin registerWithRegistrar:[registry registrarForPlugin:@"ThrioPlugin"]];
}

@end
